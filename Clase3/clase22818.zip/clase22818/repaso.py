primer_numero=34
segundoNumero=56 #fuera de la convencion

def suma_funcion(a,b):
    if(a>10):
        return 20
    if(b<20):
        return 50
    resultado = a+b
    return resultado
    # return a+b

#F string python
print(f'La suma es {primer_numero+segundoNumero}')

print(f'La suma con funcion es {suma_funcion(primer_numero,segundoNumero)}')

x=0
def funcion():
    x=1
    def funcion_interna(): #declaro funcion interna
        global x
        x=2
        print(f'Local scope x={x}')

    funcion_interna() # llamo a la funcion
    print(f'Enclosed scope x={x}')

funcion()
print(f'Global scope x={x}')






 